// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <http://www.gnu.org/licenses/>.

/**
 * M-SEB Pro Guard module — JS-based proctoring for iOS and PC.
 *
 * Detects tab switching, minimising, auto-translation, and blocks
 * right-click / copy-paste. Applies an escalating penalty timer overlay
 * for each violation.
 *
 * @module   local_mseb/proguard
 * @package  local_mseb
 * @copyright 2024 M-SEB
 * @license  http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import {get_string} from 'core/str';

/**
 * Initialise the Pro Guard proctoring module.
 *
 * @param {number} quizId  The quiz instance ID.
 * @param {boolean} isIos Whether the user is on an iOS device.
 */
export const init = async(quizId, isIos) => {
  // Only run on attempt or view pages.
  if (!/\/mod\/quiz\/(attempt|view)\.php/.test(window.location.pathname)) {
    return;
  }

  // Pre-fetch language strings.
  const strings = {
    violation: await get_string('js:violation', 'local_mseb'),
    violationCount: await get_string('js:violationcount', 'local_mseb'),
    leavingExam: await get_string('js:leavingexam', 'local_mseb'),
    autoTranslate: await get_string('js:autotranslate', 'local_mseb'),
  };

  // Anti-Google-Translate attributes.
  document.documentElement.setAttribute('translate', 'no');
  document.documentElement.classList.add('notranslate');
  if (document.body) {
    document.body.setAttribute('translate', 'no');
    document.body.classList.add('notranslate');
  }

  // Observe DOM for translation artefacts.
  const translateObserver = new MutationObserver(() => {
    if (document.querySelector('font[style*="background"]')) {
      addViolation(strings.autoTranslate);
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    translateObserver.observe(document.body, {childList: true, subtree: true});
  });

  // Session-based violation counter.
  const params = new URLSearchParams(window.location.search);
  const attemptId = params.get('attempt') || '0';
  const storageKey = `seb_v15_violation_${quizId}_${attemptId}`;
  const SLEEP_IGNORE_MS = 15000;

  let navSafe = false;
  let hiddenAt = 0;
  let ignoreBlur = false;
  let isPenaltyRunning = false;
  const penaltyEndTimeKey = `${storageKey}_endtime`;

  /**
   * Resume penalty if it was running.
   */
  const checkResumePenalty = () => {
    const endTime = parseInt(window.localStorage.getItem(penaltyEndTimeKey) || '0', 10);
    const now = Date.now();
    if (endTime > now) {
      const remaining = Math.ceil((endTime - now) / 1000);
      showPenaltyOverlay(remaining, endTime);
    }
  };

  /**
   * @returns {number} Current violation count.
   */
  const getViolations = () => parseInt(window.localStorage.getItem(storageKey) || '0', 10);

  /**
   * @param {number} v New violation count.
   */
  const setViolations = (v) => {
    window.localStorage.setItem(storageKey, String(v));
    updateMonitor(v);
  };

  // Violation monitor UI.
  let monitorEl = null;

  document.addEventListener('DOMContentLoaded', () => {
    monitorEl = document.createElement('div');
    monitorEl.style.cssText =
      'position:fixed;top:15px;right:15px;z-index:999999;' +
      'background:#0a7d00;color:#fff;padding:12px 18px;' +
      'border-radius:12px;font-size:14px;font-weight:700;' +
      'pointer-events:none;box-shadow:0 4px 6px rgba(0,0,0,0.3);';
    monitorEl.innerHTML = `${strings.violationCount}: <span id="monV">0</span>`;
    document.body.appendChild(monitorEl);
    updateMonitor(getViolations());
  });

  /**
   * Update the monitor badge colour and count.
   *
   * @param {number} v Current violation count.
   */
  const updateMonitor = (v) => {
    if (!monitorEl) {
      return;
    }
    const spanV = document.getElementById('monV');
    if (spanV) {
      spanV.textContent = v;
    }
    const colours = ['#0a7d00', '#c9a400', '#ff8800', '#ff3300', '#8b0000'];
    monitorEl.style.background = colours[Math.min(v, colours.length - 1)];
  };

  /**
   * Play an audible beep.
   *
   * @param {number} freq Frequency in Hz.
   * @param {number} dur Duration in ms.
   */
  const beep = (freq = 900, dur = 150) => {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq;
      gain.gain.value = 0.3;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      setTimeout(() => {
        osc.stop();
        ctx.close();
      }, dur);
    } catch {
      // Audio not available — ignore.
    }
  };

  const addViolation = async(reason) => {
    const v = getViolations() + 1;
    setViolations(v);
    beep(1200, 200);

    const now = Date.now();
    const penaltyDuration = v * 60 * 1000;
    const endTime = now + penaltyDuration;
    window.localStorage.setItem(penaltyEndTimeKey, String(endTime));

    showPenaltyOverlay(v * 60, endTime);
  };

  /**
   * Display the penalty overlay with a countdown.
   *
   * @param {number} seconds Countdown start.
   * @param {number} endTime Timestamp when penalty finishes.
   */
  const showPenaltyOverlay = async(seconds, endTime) => {
    if (isPenaltyRunning) {
        return;
    }
    isPenaltyRunning = true;
    let penaltySeconds = seconds;
    const v = getViolations();

    const detectedStr = await get_string('js:detected', 'local_mseb', "App Switch / Focus Loss");
    const penaltyStr = await get_string('js:penaltynotice', 'local_mseb', v);

    const overlay = document.createElement('div');
    overlay.style.cssText =
      'position:fixed;inset:0;background:rgba(211,47,47,0.98);' +
      'color:white;z-index:9999999;display:flex;flex-direction:column;' +
      'align-items:center;justify-content:center;font-family:sans-serif;text-align:center;padding:20px;';

    overlay.innerHTML = `
      <div style="font-size:80px;margin-bottom:20px;">🚨</div>
      <h1 style="font-size:28px;margin-bottom:15px;font-weight:bold;">${strings.violation}</h1>
      <p style="font-size:16px;margin-bottom:20px;">
        ${detectedStr}<br><br>${penaltyStr}
      </p>
      <div style="font-size:55px;font-weight:bold;background:white;color:#d32f2f;padding:15px 35px;border-radius:15px;">
        <span id="mseb-min">00</span>:<span id="mseb-sec">00</span>
      </div>
    `;

    document.body.appendChild(overlay);
    document.body.style.overflow = 'hidden';

    const penaltyTimer = setInterval(() => {
      penaltySeconds--;
      const mins = Math.floor(penaltySeconds / 60);
      const secs = penaltySeconds % 60;

      const minEl = document.getElementById('mseb-min');
      const secEl = document.getElementById('mseb-sec');
      if (minEl) {
        minEl.textContent = mins < 10 ? '0' + mins : String(mins);
      }
      if (secEl) {
        secEl.textContent = secs < 10 ? '0' + secs : String(secs);
      }

      if (penaltySeconds <= 0) {
        clearInterval(penaltyTimer);
        overlay.remove();
        document.body.style.overflow = '';
        isPenaltyRunning = false;
        window.localStorage.removeItem(penaltyEndTimeKey);
      }
    }, 1000);
  };

  // Safe navigation detection — avoid false positives on legitimate clicks.
  document.addEventListener('click', (e) => {
    const t = e.target;
    if (
      t.closest('#responseform') ||
      t.closest('.submitbtns') ||
      t.closest('#mod_quiz_navblock') ||
      t.closest('.qnbutton') ||
      t.tagName === 'BUTTON' ||
      (t.tagName === 'INPUT' && t.type === 'submit') ||
      t.tagName === 'A'
    ) {
      navSafe = true;
      setTimeout(() => {
        navSafe = false;
      }, 1000); // Reduced from 2000ms for tighter security.
    }
  }, true);

  // Detect tab switching / minimising / app switching.
  ['visibilitychange', 'pagehide', 'beforeunload'].forEach(evt => {
    document.addEventListener(evt, () => {
      if (evt === 'visibilitychange' && document.visibilityState !== 'hidden') {
        const diff = Date.now() - hiddenAt;
        if (diff > SLEEP_IGNORE_MS) { /* asleep */ }
        hiddenAt = 0;
        setTimeout(() => { ignoreBlur = false; }, 500);
        return;
      }
      
      hiddenAt = Date.now();
      ignoreBlur = true;
      if (!navSafe) {
        addViolation(strings.leavingExam);
      }
    });
  });

  // Detect loss of focus (clicking outside, multi-window, status bar).
  window.addEventListener('blur', () => {
    if (!navSafe && !ignoreBlur && !isPenaltyRunning) {
      addViolation(strings.leavingExam);
    }
  });

  // Heartbeat check for focus on iOS.
  if (isIos) {
    setInterval(() => {
      if (!document.hasFocus() && !navSafe && !ignoreBlur && !isPenaltyRunning) {
        addViolation(strings.leavingExam);
      }
    }, 2000);
  }

  // Initial check for resumed penalty.
  document.addEventListener('DOMContentLoaded', checkResumePenalty);
  checkResumePenalty(); // Also run immediately in case DOM already loaded.

  /**
   * Detect split-screen or small windowed mode.
   */
  const checkWindowSize = () => {
    if (navSafe || isPenaltyRunning) {
      return;
    }
    // Thresholds: if window is less than 85% of available screen size, assume split/windowed.
    const widthRatio = window.innerWidth / window.screen.availWidth;
    const heightRatio = window.innerHeight / window.screen.availHeight;

    if (widthRatio < 0.85 || heightRatio < 0.85) {
      addViolation(strings.leavingExam);
    }
  };

  // Check on resize and periodically.
  window.addEventListener('resize', checkWindowSize);
  setTimeout(checkWindowSize, 3000); // Grace period after load.

  // Block right-click and clipboard operations.
  document.addEventListener('contextmenu', (e) => e.preventDefault());
  ['copy', 'cut', 'paste'].forEach((evt) => {
    document.addEventListener(evt, (e) => e.preventDefault());
  });
};
